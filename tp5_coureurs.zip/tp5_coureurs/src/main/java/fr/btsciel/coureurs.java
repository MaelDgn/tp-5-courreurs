package fr.btsciel;

public class coureurs extends Personne {
    int duree;                 // temps en secondes
    Categorie categorie;

    public int getDuree() {
        return d uree;
    }



    public void setDuree(int duree) {
        this.duree = duree;
    }

    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }


    public coureurs(String nom, String prenom, Genre genre, Categorie age, int duree, Categorie categorie) {
        super(nom, prenom, genre, age);
        this.duree = duree;
        this.categorie = categorie;
    }

    @Override
    public String toString() {
        return getGenre() + ", " + getNom() + ", " + getPrenom()
                + ", " + categorie + ", " + duree;
    }
}
