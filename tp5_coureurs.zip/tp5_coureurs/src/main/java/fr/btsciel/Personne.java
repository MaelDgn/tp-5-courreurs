package fr.btsciel;

public class Personne {
    private String nom;
    private String prenom;
    private Genre genre ;
    private Categorie categorie;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }



    public Genre getGenre() {
        return genre;
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
    }

    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }

    public Personne(String nom, String prenom, Genre genre, Categorie age) {
        this.nom = nom;
        this.prenom = prenom;
        this.genre = genre;
        this.categorie = age;
    }
}
