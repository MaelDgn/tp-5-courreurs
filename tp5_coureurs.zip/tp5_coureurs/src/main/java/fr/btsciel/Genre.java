package fr.btsciel;

public enum Genre {
    F ,

    M ,

}

