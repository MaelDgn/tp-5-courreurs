package fr.btsciel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ihm {

    private Gestiondescoureurs gestion = new Gestiondescoureurs();
    private BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));

    public Ihm() throws IOException {
        menu();
    }



    public void menu() throws IOException {
        int choix = -1;

        while (choix != 11) {

            System.out.println("\n--- MENU ---");
            System.out.println("1  : Afficher par nom croissant");
            System.out.println("2  : Afficher par nom décroissant");
            System.out.println("3  : Afficher par prénom croissant");
            System.out.println("4  : Afficher par prénom décroissant");
            System.out.println("5  : Afficher par temps croissant");
            System.out.println("6  : Afficher par temps décroissant");
            System.out.println("7  : Ajouter un coureur");
            System.out.println("8  : Supprimer un coureur");
            System.out.println("9  : Modifier un coureur");
            System.out.println("10 : Sauvegarder");
            System.out.println("11 : Quitter");
            System.out.print("Choix : ");

            try {
                choix = Integer.parseInt(sc.readLine());
            } catch (Exception e) {
                choix = -1;
            }

            switch (choix) {
                case 1:
                    gestion.trierNomCroissant(); gestion.afficher(); break;
                case 2:
                    gestion.trierNomDecroissant(); gestion.afficher(); break;
                case 3:
                    gestion.trierPrenomCroissant(); gestion.afficher(); break;
                case 4:
                    gestion.trierPrenomDecroissant(); gestion.afficher(); break;
                case 5:
                    gestion.trierTempsCroissant(); gestion.afficher(); break;
                case 6:
                    gestion.trierTempsDecroissant(); gestion.afficher(); break;
                case 7:
                    ajouter(); break;
                case 8:
                    supprimer(); break;
                case 9:
                    modifier(); break;
                case 10:
                    gestion.sauvegarder(); break;
                case 11:
                    System.out.println("Au revoir !"); break;
                default:
                    System.out.println("Choix invalide."); break;
            }
        }
    }

    private void ajouter() throws IOException {
        System.out.print("Genre (M/F) : ");
        Genre g = Genre.valueOf(sc.readLine().trim().toUpperCase());
        System.out.print("Nom : "); String nom = sc.readLine().trim();
        System.out.print("Prénom : "); String prenom = sc.readLine().trim();
        System.out.print("Catégorie : "); Categorie cat = Categorie.valueOf(sc.readLine().trim().toUpperCase());
        System.out.print("Temps en secondes : "); int duree = Integer.parseInt(sc.readLine().trim());

        gestion.ajouter(new coureurs(nom, prenom, g, cat, duree, cat));
        System.out.println("Coureur ajouté !");
    }

    private void supprimer() throws IOException {
        System.out.print("Nom : "); String nom = sc.readLine().trim();
        System.out.print("Prénom : "); String prenom = sc.readLine().trim();
        gestion.supprimer(nom, prenom);
        System.out.println("Coureur supprimé si existant.");
    }

    private void modifier() throws IOException {
        System.out.print("Nom du coureur : "); String nom = sc.readLine().trim();
        System.out.print("Prénom du coureur : "); String prenom = sc.readLine().trim();

        coureurs cible = null;
        for (int i = 0; i < gestion.getCoureurs().size(); i++) {
            coureurs c = gestion.getCoureurs().get(i);
            if (c.getNom().equalsIgnoreCase(nom) && c.getPrenom().equalsIgnoreCase(prenom)) {
                cible = c;
                break;
            }
        }

        if (cible == null) {
            System.out.println("Coureur introuvable.");
            return;
        }

        System.out.print("Nouveau nom (laisser vide pour ne pas changer) : ");
        String newNom = sc.readLine().trim();
        if (!newNom.isEmpty()) cible.setNom(newNom);

        System.out.print("Nouveau prénom : ");
        String newPrenom = sc.readLine().trim();
        if (!newPrenom.isEmpty()) cible.setPrenom(newPrenom);

        System.out.print("Nouveau genre (M/F) : ");
        String sGenre = sc.readLine().trim();
        if (!sGenre.isEmpty()) cible.setGenre(Genre.valueOf(sGenre.toUpperCase()));

        System.out.print("Nouvelle catégorie : ");
        String sCat = sc.readLine().trim();
        if (!sCat.isEmpty()) cible.setCategorie(Categorie.valueOf(sCat.toUpperCase()));

        System.out.print("Nouveau temps en secondes : ");
        String sDuree = sc.readLine().trim();
        if (!sDuree.isEmpty()) cible.setDuree(Integer.parseInt(sDuree));

        System.out.println("Coureur modifié !");
    }

    public static void main(String[] args) throws IOException {
        new Ihm();
    }
}
