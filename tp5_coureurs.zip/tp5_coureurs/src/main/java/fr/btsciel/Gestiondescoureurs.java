package fr.btsciel;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Gestiondescoureurs {

    private ArrayList<coureurs> coureurs = new ArrayList<>();
    private Path fichier = Paths.get("course.txt");

    public Gestiondescoureurs() {
        try {
            lireFichier();
        } catch (IOException e) {
            System.out.println("Impossible de lire le fichier : " + e.getMessage());
        }
    }

    // Lecture du fichier
    public void lireFichier() throws IOException {
        coureurs.clear();
        if (!Files.exists(fichier)) return;

        BufferedReader br = Files.newBufferedReader(fichier);
        String line;

        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;

            String[] split = line.split("\\s*,\\s*");
            if (split.length != 5) {
                System.out.println("Ligne ignorée (format invalide) : " + line);
            } else {
                try {
                    Genre genre = Genre.valueOf(split[0].trim());
                    String nom = split[1].trim();
                    String prenom = split[2].trim();
                    Categorie cat = Categorie.valueOf(split[3].trim());
                    int duree = Integer.parseInt(split[4].trim());

                    coureurs.add(new coureurs(nom, prenom, genre, cat, duree, cat));
                } catch (Exception e) {
                    System.out.println("Erreur lecture ligne : " + line);
                }
            }
        }

        br.close();
    }

    // Sauvegarde
    public void sauvegarder() {
        try {
            BufferedWriter bw = Files.newBufferedWriter(fichier);
            for (coureurs c : coureurs) {
                bw.write(c.getGenre() + ", " + c.getNom() + ", " + c.getPrenom()
                        + ", " + c.getCategorie() + ", " + c.getDuree());
                bw.newLine();
            }
            bw.close();
            System.out.println("Liste sauvegardée !");
        } catch (IOException e) {
            System.out.println("Erreur sauvegarde : " + e.getMessage());
        }
    }

    // Affichage simple
    public void afficher() {
        if (coureurs.isEmpty()) {
            System.out.println("Aucun coureur.");
            return;
        }
        for (coureurs c : coureurs) {
            System.out.println(c);
        }
    }

    // Ajouter
    public void ajouter(coureurs c) {
        coureurs.add(c);
    }

    // Supprimer
    public void supprimer(String nom, String prenom) {
        Iterator<coureurs> it = coureurs.iterator();
        while (it.hasNext()) {
            coureurs c = it.next();
            if (c.getNom().equalsIgnoreCase(nom) && c.getPrenom().equalsIgnoreCase(prenom)) {
                it.remove();
            }
        }
    }

    // Getters
    public ArrayList<coureurs> getCoureurs() {
        return coureurs;
    }

    // TRIS
    public void trierNomCroissant() {
        Collections.sort(coureurs, new Comparator<coureurs>() {
            public int compare(coureurs c1, coureurs c2) {
                return c1.getNom().toLowerCase().compareTo(c2.getNom().toLowerCase());
            }
        });
    }

    public void trierNomDecroissant() {
        Collections.sort(coureurs, new Comparator<coureurs>() {
            public int compare(coureurs c1, coureurs c2) {

                return c2.getNom().toLowerCase().compareTo(c1.getNom().toLowerCase());
            }
        });
    }

    public void trierPrenomCroissant() {
        Collections.sort(coureurs, new Comparator<coureurs>() {
            public int compare(coureurs c1, coureurs c2) {
                return c1.getPrenom().toLowerCase().compareTo(c2.getPrenom().toLowerCase());
            }
        });
    }

    public void trierPrenomDecroissant() {
        Collections.sort(coureurs, new Comparator<coureurs>() {
            public int compare(coureurs c1, coureurs c2) {
                return c2.getPrenom().toLowerCase().compareTo(c1.getPrenom().toLowerCase());
            }
        });
    }

    public void trierTempsCroissant() {
        Collections.sort(coureurs, new Comparator<coureurs>() {
            public int compare(coureurs c1, coureurs c2) {
                return c1.getDuree() - c2.getDuree();
            }
        });
    }

    public void trierTempsDecroissant() {
        Collections.sort(coureurs, new Comparator<coureurs>() {
            public int compare(coureurs c1, coureurs c2) {
                return c2.getDuree() - c1.getDuree();
            }
        });
    }
}
