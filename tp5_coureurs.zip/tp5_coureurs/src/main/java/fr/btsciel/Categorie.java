public enum Categorie {
    M1;
    M2;
    M3;
    M4;
    M5;

    M6;
    M7;
    M8;

    M9;
    ELITE_1;
    ELITE_2;
}

